
### Compilation and Deployment Procedure

1.  **Compile the Utility** 
    * First, compile the `genbin.cpp` source file using GCC:
        `gcc genbin.cpp -o genbin` 

2.  **Prepare Directory Structure** 
    * Place the `htdocs/` directory, which contains the web source code, in the same directory as the compiled `genbin` executable. 

3.  **Generate Binary File** 
    * Execute the `genbin` utility:
        `./genbin` 

4.  **Deploy for Testing** 
    * After the `htdocs.bin` file is generated, replace the existing `htdocs.bin` file on the SD card to proceed with testing. 
	
5.  **Test URL**
	* URL: `http://ip/main`
	
Note:How to generate the htdocs.h
You can convert the binary into htdocs.h
gcc bin2h.c -o bin2h
./bin2h htdocs.bin
